import { useState } from 'react'
import { supabase } from '../utils/supabase'

export default function Home() {
  const [link, setLink] = useState('')
  const [form, setForm] = useState({
    title: '',
    description: '',
    url: '',
    image: null
  })

  const handleImage = (e) => {
    const file = e.target.files[0]
    const reader = new FileReader()
    reader.onload = (e) => {
      setForm({...form, image: e.target.result})
    }
    reader.readAsDataURL(file)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const { data, error } = await supabase
      .from('links')
      .insert([form])
      .single()

    if (!error) {
      setLink(`${window.location.origin}/link/${data.id}`)
    }
  }

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
      <h1>Create Social Media Link</h1>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <input
          type="text"
          placeholder="Title"
          required
          onChange={(e) => setForm({...form, title: e.target.value})}
        />
        <textarea
          placeholder="Description"
          onChange={(e) => setForm({...form, description: e.target.value})}
        />
        <input
          type="url"
          placeholder="Destination URL"
          required
          onChange={(e) => setForm({...form, url: e.target.value})}
        />
        <input
          type="file"
          accept="image/*"
          required
          onChange={handleImage}
        />
        <button type="submit">Generate Link</button>
      </form>
      {link && <div style={{ marginTop: '20px' }}>
        <p>Your Vercel Link:</p>
        <a href={link} target="_blank">{link}</a>
      </div>}
    </div>
  )
}