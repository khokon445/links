import { supabase } from '../../utils/supabase'

export async function getServerSideProps({ params }) {
  const { data } = await supabase
    .from('links')
    .select('*')
    .eq('id', params.id)
    .single()

  return { props: { data } }
}

export default function LinkPage({ data }) {
  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      <a href={data.url} style={{ textDecoration: 'none', color: 'inherit' }}>
        <h1>{data.title}</h1>
        <img 
          src={data.image} 
          alt={data.title} 
          style={{ maxWidth: '100%', height: 'auto', margin: '20px 0' }}
        />
        <p>{data.description}</p>
      </a>
    </div>
  )
}